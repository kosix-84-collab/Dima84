﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.0.1
     ** Copyright © CashaCX75. All Rights Reserved
     */

    try {
      (() => {
        //dynamic modify start


        let editBg = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_fat_burning_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_floor_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_DIRECTION_img_LEVEL = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_altimeter_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_calendar_img_click = ''
		let normal_anim_h='';
		let normal_anim_h_group='';
		let anim_f=10;
		let fps_s=30;
		let sleep_time_txt = ''
		
		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		//let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();

		let sleepStageArray = sleep.getSleepStageData();
		const modelData = sleep.getSleepStageModel();
		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepStageArray = sleep.getSleepStageData();
			//sleepInfo = sleep.getBasicInfo();
			
		let wakeTime = 0;
		sleepStageArray = sleep.getSleepStageData();
			
			for (let i = 0; i < sleepStageArray.length; i++) {
			  let data = sleepStageArray[i];
			  if (data.model == modelData.WAKE_STAGE){
					wakeTime += data.stop + 1 - data.start;
			  }

			}
			
			sleepTotalTime -= wakeTime;

		sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current,
          {
            px: i
          } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o)),
            e.__globals__),
          n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
          init_view() {
            //dynamic modify start
			

            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [{
                  id: 1,
                  preview: 'bg_edit_1_preview.png',
                  path: 'main_1.png'
                },
                {
                  id: 2,
                  preview: 'bg_edit_2_preview1.png',
                  path: 'main_2.png'
                },
                {
                  id: 3,
                  preview: 'bg_edit_3_preview1.png',
                  path: 'main_3.png'
                },
                {
                  id: 4,
                  preview: 'bg_edit_4_preview1.png',
                  path: 'main_4.png'
                },
                {
                  id: 5,
                  preview: 'bg_edit_5_preview1.png',
                  path: 'main_5.png'
                },
                {
                  id: 6,
                  preview: 'bg_edit_6_preview1.png',
                  path: 'main_6.png'
                },
                {
                  id: 7,
                  preview: 'bg_edit_7_preview.png',
                  path: 'main_7.png'
                },
              ],
              count: 7,
              default_id: 1,
              fg: 'ramka.png',
              tips_bg: 'podskaz.png',
              tips_x: 180,
              tips_y: 309,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 369,
              font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat_14.png',
              unit_tc: 'bat_14.png',
              unit_en: 'bat_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 60,
              month_sc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
              month_tc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
              month_en_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
              month_is_character: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 67,
              week_en: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
              week_tc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
              week_sc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 67,
              day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
              day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
              day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 363,
              am_y: 232,
              am_sc_path: '0003.png',
              am_en_path: '0003.png',
              pm_x: 363,
              pm_y: 232,
              pm_sc_path: '0004.png',
              pm_en_path: '0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 198,
              hour_array: ["hour_0.png", "hour_1.png", "hour_2.png", "hour_3.png", "hour_4.png", "hour_5.png", "hour_6.png", "hour_7.png", "hour_8.png", "hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'hour_10.png',
              hour_unit_tc: 'hour_10.png',
              hour_unit_en: 'hour_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 170,
              minute_array: ["hour_0.png", "hour_1.png", "hour_2.png", "hour_3.png", "hour_4.png", "hour_5.png", "hour_6.png", "hour_7.png", "hour_8.png", "hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 264,
              second_array: ["sec_0.png", "sec_1.png", "sec_2.png", "sec_3.png", "sec_4.png", "sec_5.png", "sec_6.png", "sec_7.png", "sec_8.png", "sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 317,
              font_array: ["kcal_0.png", "kcal_1.png", "kcal_2.png", "kcal_3.png", "kcal_4.png", "kcal_5.png", "kcal_6.png", "kcal_7.png", "kcal_8.png", "kcal_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'kcal_10.png',
              unit_tc: 'kcal_10.png',
              unit_en: 'kcal_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,			
              y: 304,			
			  w: 100,			
			  h: 50,			
			  text_size: 33,	
			  text: '',
			  color: 0xffffff,	
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 317,
              font_array: ["kcal_0.png", "kcal_1.png", "kcal_2.png", "kcal_3.png", "kcal_4.png", "kcal_5.png", "kcal_6.png", "kcal_7.png", "kcal_8.png", "kcal_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.LAST, function() {
		      	  animation_call()
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 314,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 360,
              font_array: ["st_0.png", "st_1.png", "st_2.png", "st_3.png", "st_4.png", "st_5.png", "st_6.png", "st_7.png", "st_8.png", "st_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 414,
              font_array: ["dist_0.png", "dist_1.png", "dist_2.png", "dist_3.png", "dist_4.png", "dist_5.png", "dist_6.png", "dist_7.png", "dist_8.png", "dist_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dist_11.png',
              unit_tc: 'dist_11.png',
              unit_en: 'dist_11.png',
              dot_image: 'dist_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 163,
              w: 170,
              h: 30,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 126,
              font_array: ["temp_0.png", "temp_1.png", "temp_2.png", "temp_3.png", "temp_4.png", "temp_5.png", "temp_6.png", "temp_7.png", "temp_8.png", "temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp_12.png',
              unit_tc: 'temp_12.png',
              unit_en: 'temp_12.png',
              negative_image: 'temp_10.png',
              invalid_image: 'temp_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 126,
              font_array: ["temp_0.png", "temp_1.png", "temp_2.png", "temp_3.png", "temp_4.png", "temp_5.png", "temp_6.png", "temp_7.png", "temp_8.png", "temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp_12.png',
              unit_tc: 'temp_12.png',
              unit_en: 'temp_12.png',
              negative_image: 'temp_10.png',
              invalid_image: 'temp_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 273,
              y: 126,
              src: 'temp_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 126,
              font_array: ["temp_0.png", "temp_1.png", "temp_2.png", "temp_3.png", "temp_4.png", "temp_5.png", "temp_6.png", "temp_7.png", "temp_8.png", "temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp_12.png',
              unit_tc: 'temp_12.png',
              unit_en: 'temp_12.png',
              negative_image: 'temp_10.png',
              invalid_image: 'temp_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 113,
              image_array: ["weat_1.png", "weat_2.png", "weat_3.png", "weat_4.png", "weat_5.png", "weat_6.png", "weat_7.png", "weat_8.png", "weat_9.png", "weat_10.png", "weat_11.png", "weat_12.png", "weat_13.png", "weat_14.png", "weat_15.png", "weat_16.png", "weat_17.png", "weat_18.png", "weat_19.png", "weat_20.png", "weat_21.png", "weat_22.png", "weat_23.png", "weat_24.png", "weat_25.png", "weat_26.png", "weat_27.png", "weat_28.png", "weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 204,
              font_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 237,
              font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 271,
              font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 126,
              font_array: ["temp_0.png", "temp_1.png", "temp_2.png", "temp_3.png", "temp_4.png", "temp_5.png", "temp_6.png", "temp_7.png", "temp_8.png", "temp_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_DIRECTION_img_LEVEL = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 126,
              image_array: ["wind_1.png", "wind_2.png", "wind_3.png", "wind_4.png", "wind_5.png", "wind_6.png", "wind_7.png", "wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0002.png',
              center_x: 199,
              center_y: 40,
              x: 3,
              y: 11,
              start_angle: -140,
              end_angle: 140,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 28,
              font_array: ["temp_0.png", "temp_1.png", "temp_2.png", "temp_3.png", "temp_4.png", "temp_5.png", "temp_6.png", "temp_7.png", "temp_8.png", "temp_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 96,
              image_array: ["moon_1.png", "moon_2.png", "moon_3.png", "moon_4.png", "moon_5.png", "moon_6.png", "moon_7.png", "moon_8.png", "moon_9.png", "moon_10.png", "moon_11.png", "moon_12.png", "moon_13.png", "moon_14.png", "moon_15.png", "moon_16.png", "moon_17.png", "moon_18.png", "moon_19.png", "moon_20.png", "moon_21.png", "moon_22.png", "moon_23.png", "moon_24.png", "moon_25.png", "moon_26.png", "moon_27.png", "moon_28.png", "moon_29.png", "moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 171,
              font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'bat_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 171,
              font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'bat_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 199,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 200,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 353,
              y: 251,
              w: 60,
              h: 60,
              src: '0005.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 100,
              w: 60,
              h: 60,
              src: '0005.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 355,
              w: 100,
              h: 50,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'Settings_batteryManagerScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 357,
              w: 100,
              h: 80,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'activityAppScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_calendar_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 60,
              w: 60,
              h: 60,
              src: 'pusto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calendar_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'ScheduleCalScreen',
                native: true
              })
            });
			
			let anim_sz=10;
			
			
			function animation_call(){
				if(typeof normal_anim_h !== 'string'){
					hmUI.deleteWidget(normal_anim_h);
				}	
							
				if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {

					if(!isNaN(heart_rate.last) && heart_rate.last > 10){
						anim_sz=Math.ceil(30/(heart_rate.last/60));
					}else{
						anim_sz=20;
					}

					normal_anim_h = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						  anim_path: 'animation',
						  anim_prefix: 'heart',
						  anim_ext: 'png',
						  anim_fps: Math.ceil(heart_rate.last/10),//6,//30,
						  repeat_count: 0,
						  anim_size: 6,//anim_sz,
						  anim_status: hmUI.anim_status.START,
						  anim_repeat: true,
						  x: 69,//0,
						  y: 354,//0,
						  show_level: hmUI.show_level.ONLY_NORMAL,
						});	
//					normal_anim_h.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);					
				}
			}


            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                updateSleepInfo();
				scale_call();
				animation_call();
              }),
            });

            //dynamic modify end
          },
          onInit() {
            n.log("index page.js on init invoke")
          },
          build() {
            this.init_view(),
              n.log("index page.js on ready invoke")
          },
          onDestroy() {
            n.log("index page.js on destroy invoke")
          }
        })
      })()
    } catch (e) {
      console.log("Mini Program Error", e),
        e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
    }
